package com.project.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class ItemDB extends SQLiteOpenHelper {

    public static final String DB_NAME = "Items.db";

    public ItemDB(Context context) {
        super(context, "Items.db", null, 1);
    }

    //Creates item and amount without primary key, so duplicate entries are allowed
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table inventory(item string, amount string)");
    }

    //Checks if table exists and enables deletion of table
    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
        MyDB.execSQL("drop Table if exists inventory");

    }

    //insert method to add to inventory database
    //also returns a boolean for other checks
    public Boolean insert(String item, String amount){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item", item);
        contentValues.put("amount", amount);
        long result = MyDB.insert("inventory", null, contentValues);

        if (result == -1)
            return false;
        else
            return true;
    }

    //Clears database
    public void delete() {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        String clearDBQuery = "DELETE FROM " + "inventory";
        MyDB.execSQL(clearDBQuery);
    }

    //Returns a list to rebuild Inventory on database activity
    public List<String> copyFromDB() {

        //initialize list
        List<String> editTextList = new ArrayList<String>();
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("SELECT * FROM " + "inventory", null);

        //Iterates through SQL database and adds data to a list
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                String tempItem = cursor.getString(cursor.getColumnIndex("item"));
                String tempAmount = cursor.getString(cursor.getColumnIndex("amount"));

                editTextList.add(tempItem);
                editTextList.add(tempAmount);

                cursor.moveToNext();
            }
        }

        //close cursor when finished
        cursor.close();

        //returns created list
        return editTextList;
    }
}
