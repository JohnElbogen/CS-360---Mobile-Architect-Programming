package com.project.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class LogDB extends SQLiteOpenHelper {

    public static final String DB_NAME = "Login.db";

    public LogDB(Context context) {
        super(context, "Login.db", null, 1);
    }

    //Creates user as primary key and password
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    //Checks if table exists and enables deletion of table
    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int oldVersion, int newVersion) {
        MyDB.execSQL("drop Table if exists users");

    }

    //insert method to add to Login database
    //also returns a boolean for other checks
    public Boolean insert(String username, String password){

        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("username", username);
        contentValues.put("password", password);

        long result = MyDB.insert("users", null, contentValues);

        if (result == -1)
            return false;
        else
            return true;
    }

    //Method checks a username against existing names
    //returns true or false
    public Boolean checkUserExists(String username){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[] {username});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    //Method checks a password with a username against username/password combination
    //returns true or false
    public Boolean checkUserPassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }

}
