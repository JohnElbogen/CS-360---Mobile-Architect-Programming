package com.project.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class LogInActivity extends AppCompatActivity {
    private EditText username, password;
    private Button login, register;
    private LogDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Assigning my activity layout features
        username = findViewById(R.id.editTextTextUsername);
        password = findViewById(R.id.editTextTextPassword);
        login = findViewById(R.id.logButton);
        register = findViewById(R.id.regButton);

        //new log database object
        db = new LogDB(this);

        //onclick listener for button
        login.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                //gets user name and password string
                String userString = username.getText().toString();
                String passString = password.getText().toString();

                //check fields are not empty, and sends Toasts
                //after conditional passes, with correct User/Pass moves to next activity
                if (userString.equals("") || passString.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUserExists = db.checkUserExists(userString);
                    Boolean checkPassExists = db.checkUserPassword(userString, passString);

                    if (checkUserExists == true && checkPassExists == true){
                        openDatabaseActivity();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Invalid User/Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //onclick listener for button
        register.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                //gets user name and password string
                String userString = username.getText().toString();
                String passString = password.getText().toString();

                //check fields are not empty, and sends Toasts
                //Also checks if username exists, if not adds username/password to LogDB Database
                if (userString.equals("") || passString.equals("")){
                    Toast.makeText(getApplicationContext(),"Fields are empty", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkUserExists = db.checkUserExists(userString);

                    if (!checkUserExists == true){
                        Boolean insert = db.insert(userString, passString);
                        if (insert == true){
                            Toast.makeText(getApplicationContext(),"Registered", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"User Name Already Exists", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    //Moves to next activity
    public void openDatabaseActivity() {
        Intent intent = new Intent(this, DatabaseActivity.class);
        startActivity(intent);
    }

}