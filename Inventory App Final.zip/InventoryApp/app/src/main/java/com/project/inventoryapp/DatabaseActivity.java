package com.project.inventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class DatabaseActivity extends AppCompatActivity{
    private Button addAlertButton, addItemButton, saveInventoryButton;
    private ImageButton deleteItemButton;
    private EditText itemName, itemAmount;
    private List<View> listViews = new ArrayList<>();
    private int index = 0;
    private ItemDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        //Create new Item database object
        db = new ItemDB(this);

        //Adds listener for add alert button
        //Just opens permission for SMS
        addAlertButton = findViewById(R.id.addAlertButton);
        addAlertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPermissionRequest();
            }
        });

        //Adds listener for add Item button
        //passes in empty fields
        addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {addItemButton("","");}
        });

        //Adds listener for add save button
        //Will save current inventory into item database
        saveInventoryButton = findViewById(R.id.saveButton);
        saveInventoryButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {saveInventoryButton();}
        });

        //Calls to methods which pull the current item database
        //Initializes this data on activity start
        addInitialDB(db.copyFromDB());

    }

    //Requests permission to send SMS
    public void openPermissionRequest(){
        requestSmsPermission();
    }

    //Loads the initial database on activity launch
    //Takes in a list which is made from iterating over the stored Item database
    //These values are passed into the addItemButton to recreate current inventory
    //on load up
    public void addInitialDB(List<String> editTextList){

        for (int i = 0; i < editTextList.size(); i += 2){
            addItemButton(editTextList.get(i), editTextList.get(i+1));
        }

    }

    //Adds new row of inventory takes in value to set item and value to set amount
    //Default values are ""
    public void addItemButton(String setItem, String setAmount) {

        //inflater pushes layout_gettext into the scroll view
        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate(R.layout.layout_gettext, null);
        LinearLayout inventory = findViewById(R.id.scrollViewLayout);

        //Used on initialization of activity
        //Edits the editTexts with database value
        EditText editItem = view.findViewById(R.id.getUpdateItem);
        if (setItem != ""){
            editItem.setText(setItem);
        }
        //Used on initialization of activity
        //Edits the editTexts with database value
        EditText editAmount = view.findViewById(R.id.getUpdateAmount);
        if (setItem != ""){
            editAmount.setText(setAmount);
        }

        //Adds view into the scrollview
        inventory.addView(view);

        //adds view into list view for later retrieval
        listViews.add(view);

        //keeps track of the current index for delete button listener
        index = listViews.indexOf(view);

        //makes all delete buttons have a listener and uses
        //index variable to delete corresponding row in app
        deleteItemButton = view.findViewById(R.id.deleteItemButton);
        deleteItemButton.setOnClickListener(new View.OnClickListener(){
            View currView = listViews.get(index);
            @Override
            public void onClick(View view) {
                deleteItemButton(currView);}
        });

    }

    //Deletes inventory row and takes in currView which is an index
    public void deleteItemButton(View currView){

        //removes row from list and inventory using index
        LinearLayout inventory = findViewById(R.id.scrollViewLayout);
        listViews.remove(currView);
        inventory.removeView(currView);

    }

    //writes data to sql database
    //sends notification with permissions on 0 amount of inventory item
    public void saveInventoryButton() {
        //clears the current database
        db.delete();

        //iterates through list of views, gets and converts values to strings
        //calls insert function to rebuild SQL database
        for (int i = 0; i < listViews.size(); i++){

            itemName = listViews.get(i).findViewById(R.id.getUpdateItem);
            itemAmount = listViews.get(i).findViewById(R.id.getUpdateAmount);

            String item = itemName.getText().toString();
            String amount = itemAmount.getText().toString();

            db.insert(item, amount);

            //Sends text message if amount of item is = 0
            if((ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) && amount.equals("0")){
                sendTextReminder(item);
            }

        }

    }

    //Send text message to user
    //Replace destination address to correct phone #
    public void sendTextReminder(String restock){
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("15555215554", null, "Reminder To Restock on " + restock + "!", null, null);
    }

    //Permission Request used on clicking to add alerts
    //Will continue to ask on button click until user clicks allow
    private void requestSmsPermission() {
        String permission = Manifest.permission.SEND_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if ( grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        }
    }

}